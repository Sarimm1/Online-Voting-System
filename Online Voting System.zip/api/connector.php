<?php
    $connect = mysqli_connect("localhost","root","","votingsystem");

    if($connect){
        echo "Connected!";
    }
    else{
        echo "Not Connected";
    }
?>